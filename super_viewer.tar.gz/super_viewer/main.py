from PySide6.QtCore import *
from PySide6.QtWidgets import *
from PySide6.QtGui import *
import sys, os
import resurse
from PIL import Image
import time
from ui_window import *
from config import *

    

class logic(QMainWindow):
    def __init__(self):
        super(logic, self).__init__()
    
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)       

        self.actionopen = QAction(self.ui.toolBar)
        self.actionopen.setObjectName(u"actionopen")
        open_icon = QIcon()
        open_icon.addFile(u":/icons/icons/book-open.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.actionopen.setIcon(open_icon)
        self.actionopen.triggered.connect(self.open)

        self.actioncrop = QAction(self.ui.toolBar)
        self.actioncrop.setObjectName("actioncrop")
        crop_icon = QIcon()
        crop_icon.addFile(u":/icons/icons/zoom-out.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.actioncrop.setIcon(crop_icon)
        self.actioncrop.triggered.connect(self.crop)  

        self.actionincrease = QAction(self.ui.toolBar)
        self.actionincrease.setObjectName("actioncrop")
        increase_icon = QIcon()
        increase_icon.addFile(u":/icons/icons/zoom-in.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.actionincrease.setIcon(increase_icon)
        self.actionincrease.triggered.connect(self.increase)  

        self.action_rotate_left = QAction(self.ui.toolBar)
        self.action_rotate_left.setObjectName("action_rotate_left")
        rotate_left_icon = QIcon()
        rotate_left_icon.addFile(u":/icons/icons/rotate-ccw.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.action_rotate_left.setIcon(rotate_left_icon)
        self.action_rotate_left.triggered.connect(self.rotate_left)   

        self.action_rotate_right = QAction(self.ui.toolBar)
        self.action_rotate_right.setObjectName("action_rotate_left")
        rotate_right_icon = QIcon()
        rotate_right_icon.addFile(u":/icons/icons/rotate-cw.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.action_rotate_right.setIcon(rotate_right_icon)
        self.action_rotate_right.triggered.connect(self.rotate_right)                 

        self.ui.menuBar.addAction("open", self.open)
        self.ui.menuBar.addAction("crop", self.crop)
        self.ui.menuBar.addAction("increase", self.increase)
        self.ui.menuBar.addAction("rotate_left", self.rotate_left)
        self.ui.menuBar.addAction("rotate_right", self.rotate_right)
        self.ui.toolBar.addSeparator()
        self.ui.toolBar.addAction(self.actionopen)        
        self.ui.toolBar.addAction(self.actioncrop)
        self.ui.toolBar.addAction(self.actionincrease)
        self.ui.toolBar.addAction(self.action_rotate_left)
        self.ui.toolBar.addAction(self.action_rotate_right)
        
        self.img = None        
        self.picSize = None

        self.index = 0
        self.dir = None

        self.connect()

    def connect(self):
        self.ui.pushButton_2.clicked.connect(self.next)  
        self.ui.pushButton.clicked.connect(self.last) 
        

    def set_Image(self, img, size):
        fn_label = self.ui.fn_label
        label = self.ui.label        
        self.img = QPixmap(img).scaled(size)

        #put a picture on label
        label.setPixmap(self.img) 
        fn_label.setText(os.listdir(self.dir_)[self.index])       


    def open(self):
        self.index = 0

        label = self.ui.label
        self.picSize = QSize(label.width() / 1 , label.height() / 1)    
        try:
            self.dir_ = QFileDialog.getExistingDirectory(self, 'Select a folder:', open_)
            file, extention = os.path.splitext(os.listdir(self.dir_)[self.index])

            print(os.listdir(self.dir_))

            self.img_path = self.dir_ + "/" + os.listdir(self.dir_)[self.index]

            if extention in (".jpeg", ".jpg", ".png", ".svg"):                        
                self.set_Image(self.img_path, self.picSize)
            else:
                label.setText("it isn't image!!!!!!!!!!!!!!!!!")                

        except FileNotFoundError:
            label.setText("it isn't image!!!!!!!!!!!!!!!!!")

    def next(self):   
        label = self.ui.label  
        self.picSize = QSize(label.width() / 1 , label.height() / 1)       
        try:       
            try:
                self.index += 1
                file, extention = os.path.splitext(os.listdir(self.dir_)[self.index])           
                self.img_path = self.dir_ + "/" + os.listdir(self.dir_)[self.index]                

                if extention in (".jpeg", ".jpg", ".png", ".svg", ".webp", "bmp"):
                    self.set_Image(self.img_path, self.picSize)
                else:
                    label.setText("it isn't image!!!!!!!!!!!!!!!!!")                   
                
            except IndexError:
                self.index = 0                
                self.set_Image(self.img_path, self.picSize)                

        except AttributeError:
               label.setText("it isn't image!!!!!!!!!!!!!!!!!")   


    def last(self): 
        label = self.ui.label
        self.picSize = QSize(label.width() / 1 , label.height() / 1)           
        try:
            self.index -= 1
            file, extention = os.path.splitext(os.listdir(self.dir_)[self.index])
            self.img_path = self.dir_ + "/" + os.listdir(self.dir_)[self.index]

            if extention in (".jpeg", ".jpg", ".png", ".svg"):                
                self.set_Image(self.img_path, self.picSize)               
            else:
                label.setText("it isn't image!!!!!!!!!!!!!!!!!")                

        except IndexError:
            self.index = 0                
            self.set_Image(self.img_path, self.picSize) 


    def crop(self):
        label = self.ui.label       

        self.picSize = QSize(label.width() / scale_plus , label.height() / scale_plus)
        self.img_path = self.dir_ + "/" + os.listdir(self.dir_)[self.index]

        self.set_Image(self.img_path, self.picSize)

    def increase(self):
        label = self.ui.label       

        self.picSize = QSize(label.width() / scale_minus , label.height() / scale_minus)
        self.img_path = self.dir_ + "/" + os.listdir(self.dir_)[self.index]

        self.set_Image(self.img_path, self.picSize)


    def rotate_left(self):
        label = self.ui.label
        transform = QTransform().rotate(-rotate) 
        self.img = self.img.transformed(transform, Qt.SmoothTransformation)

        label.setPixmap(self.img)

    def rotate_right(self):
        label = self.ui.label
        transform = QTransform().rotate(rotate) 
        self.img = self.img.transformed(transform, Qt.SmoothTransformation)

        label.setPixmap(self.img)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    log = logic()
    log.show()
    sys.exit(app.exec_())