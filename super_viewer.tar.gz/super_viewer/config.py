scale_plus = 4
scale_minus = 0.5
rotate = 90
open_ = '/home/shida/'
